//>>built
define("dijit/form/nls/it/Textarea",({iframeEditTitle:"modifica area",iframeFocusTitle:"modifica frame area"}));
