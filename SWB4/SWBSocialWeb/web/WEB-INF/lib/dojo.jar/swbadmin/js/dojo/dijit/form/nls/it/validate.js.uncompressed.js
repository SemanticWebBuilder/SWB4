define(
"dijit/form/nls/it/validate", ({
	invalidMessage: "Il valore immesso non è valido.",
	missingMessage: "Questo valore è obbligatorio.",
	rangeMessage: "Questo valore è fuori dall'intervallo consentito."
})
);
